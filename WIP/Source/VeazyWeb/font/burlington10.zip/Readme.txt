------------------------------------------------------------------------
SF Burlington Script - Version 1.0
------------------------------------------------------------------------

The following fonts are included:

 - SF Burlington Script
 - SF Burlington Script Bold
 - SF Burlington Script Bold Italic
 - SF Burlington Script Italic
 - SF Burlington Script SC
 - SF Burlington Script SC Bold
 - SF Burlington Script SC Bold Italic
 - SF Burlington Script SC Italic

------------------------------------------------------------------------
SF Burlington Script - Version 1.0 - Features
------------------------------------------------------------------------

 - Includes complete character set (lowercase and uppercase letters,
   numbers, punctuation, and accented characters).
 - Hand spacing and kerning.
 - Print & preview embedding allowed.

------------------------------------------------------------------------
ShyFonts Freeware Terms of Use
------------------------------------------------------------------------

By downloading this font package you agree to the following terms
of use:

 - This FONT PACKAGE is freeware.

 - This FONT PACKAGE may be distributed ONLY via the Internet for
   FREE.  Under NO circumstances may this FONT PACKAGE be sold for
   a profit nor be included as part of another product or CD-ROM
   compilation.  If you wish to include this FONT PACKAGE for FREE
   distribution on your Web Site, please  include all of the fonts
   and original documentation supplied with this FONT PACKAGE.

 - You may install and use this FONT PACKAGE on an unlimited
   amount of machines.

 - You may NOT rename, edit, or create any alternate variations of
   the fonts included in this FONT PACKAGE.

 - This FONT PACKAGE comes "as is" with NO warranty whatsoever.
   SHYFONTS accepts NO responsibility for any damages or loss of
   any kind due to the use of this FONT PACKAGE.  The use of this
   FONT PACKAGE is solely your responsibility -- you use this FONT
   PACKAGE at your own risk.

 - Enjoy the fonts!

If you have any question regarding this document or the usage of
this font package, feel free to contact us at info@shyfonts.com.
Thank you for downloading this font package and enjoy!

------------------------------------------------------------------------
�2000 ShyFonts Type Foundry -- http://www.shyfonts.com